#include "app/theme_palette.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iostream>

namespace {

int failures = 0;
#define CHECK(...) do { if (!(__VA_ARGS__)) { ++failures; std::cerr << __FUNCTION__ << ": " #__VA_ARGS__ " failed at " << __LINE__ << '\n'; } } while (false)

double linear_channel(std::uint8_t value) {
    const double channel = static_cast<double>(value) / 255.0;
    return channel <= 0.04045 ? channel / 12.92
                              : std::pow((channel + 0.055) / 1.055, 2.4);
}

double luminance(std::uint32_t color) {
    return 0.2126 * linear_channel(static_cast<std::uint8_t>(color >> 16U)) +
           0.7152 * linear_channel(static_cast<std::uint8_t>(color >> 8U)) +
           0.0722 * linear_channel(static_cast<std::uint8_t>(color));
}

double contrast_ratio(std::uint32_t first, std::uint32_t second) {
    const double first_luminance = luminance(first);
    const double second_luminance = luminance(second);
    const double lighter = std::max(first_luminance, second_luminance);
    const double darker = std::min(first_luminance, second_luminance);
    return (lighter + 0.05) / (darker + 0.05);
}

void check_contrast_contract(const calendar::ThemePalette& palette) {
    constexpr double kMinimumContrast = 4.5;
    CHECK(contrast_ratio(palette.text_primary, palette.surface) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.text_secondary, palette.surface) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.text_muted, palette.surface) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.text_secondary, palette.input_inset) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.action, palette.on_action) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.selection, palette.on_selection) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.today_fill, palette.today_text) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.header, palette.on_header) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.header, palette.status_normal) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.header, palette.status_attention) >= kMinimumContrast);
    CHECK(contrast_ratio(palette.header, palette.status_error) >= kMinimumContrast);
}

void test_selection_and_exact_tokens() {
    const calendar::ThemePalette& light = calendar::light_palette();
    const calendar::ThemePalette& dark = calendar::dark_palette();
    CHECK(&calendar::palette_for(false) == &light);
    CHECK(&calendar::palette_for(true) == &dark);
    CHECK(light.canvas == 0xF4F6F7U && light.surface == 0xFFFFFFU &&
          light.surface_subtle == 0xF7F9FAU && light.surface_muted == 0xE9EFF1U &&
          light.input_inset == 0xEEF2F3U && light.header == 0x142A33U &&
          light.on_header == 0xFFFFFFU && light.text_primary == 0x122B34U &&
          light.text_secondary == 0x38535DU && light.text_muted == 0x5B737BU &&
          light.border == 0x7A9098U && light.divider == 0xC4D0D4U &&
          light.action == 0x147A8AU && light.on_action == 0xFFFFFFU &&
          light.action_pressed == 0x0E5A66U && light.selection == 0x147A8AU &&
          light.on_selection == 0xFFFFFFU && light.action_soft == 0xDCECEFU &&
          light.focus == 0x0A7184U && light.today_fill == 0xFFF0D5U &&
          light.today_text == 0x704400U && light.today_ring == 0xA56600U &&
          light.status_normal == 0xBFE7ECU && light.status_attention == 0xFFD486U &&
          light.status_error == 0xFFB7AEU);
    CHECK(dark.canvas == 0x0E161BU && dark.surface == 0x141E24U &&
          dark.surface_subtle == 0x19262DU && dark.surface_muted == 0x111B21U &&
          dark.input_inset == 0x0F181DU && dark.header == 0x080F13U &&
          dark.on_header == 0xFFFFFFU && dark.text_primary == 0xF1F6F8U &&
          dark.text_secondary == 0xD3E0E4U && dark.text_muted == 0xA4B7BEU &&
          dark.border == 0x5A717AU && dark.divider == 0x2A3B43U &&
          dark.action == 0x5BC2D5U && dark.on_action == 0x071419U &&
          dark.action_pressed == 0x3196AAU && dark.selection == 0x285C69U &&
          dark.on_selection == 0xFFFFFFU && dark.action_soft == 0x213B43U &&
          dark.focus == 0x73D3E3U && dark.today_fill == 0x493A20U &&
          dark.today_text == 0xFFD58CU && dark.today_ring == 0xDEA34EU &&
          dark.status_normal == 0xBDEAF0U && dark.status_attention == 0xFFD58CU &&
          dark.status_error == 0xFFB7AEU);
}

void test_accessible_contrast() {
    check_contrast_contract(calendar::light_palette());
    check_contrast_contract(calendar::dark_palette());
}

}  // namespace

int main() {
    test_selection_and_exact_tokens();
    test_accessible_contrast();
    if (failures != 0) {
        std::cerr << failures << " theme palette test(s) failed\n";
        return 1;
    }
    std::cout << "theme palette tests passed\n";
    return 0;
}
