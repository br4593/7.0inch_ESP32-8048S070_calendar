#pragma once

#include <cstdint>

namespace calendar {

// Semantic colors for the Modern Quiet Utility appearance.  Consumers select
// colors by role so the Light/Dark choice remains a complete, consistent
// palette rather than a collection of widget-specific conditionals.
struct ThemePalette {
    std::uint32_t canvas;
    std::uint32_t surface;
    std::uint32_t surface_subtle;
    std::uint32_t surface_muted;
    std::uint32_t input_inset;
    std::uint32_t header;
    std::uint32_t on_header;
    std::uint32_t text_primary;
    std::uint32_t text_secondary;
    std::uint32_t text_muted;
    std::uint32_t border;
    std::uint32_t divider;
    std::uint32_t action;
    std::uint32_t on_action;
    std::uint32_t action_pressed;
    std::uint32_t selection;
    std::uint32_t on_selection;
    std::uint32_t action_soft;
    std::uint32_t focus;
    std::uint32_t today_fill;
    std::uint32_t today_text;
    std::uint32_t today_ring;
    std::uint32_t status_normal;
    std::uint32_t status_attention;
    std::uint32_t status_error;
};

const ThemePalette& light_palette();
const ThemePalette& dark_palette();
const ThemePalette& palette_for(bool dark_theme);

}  // namespace calendar
