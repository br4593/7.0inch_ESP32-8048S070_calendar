#include "fixtures.hpp"
#include "app/ui_controller.hpp"
#include "Arduino.h"
#include <lvgl.h>
extern "C" {
#include "ui_generated/screens.h"
#include "ui_generated/ui.h"
}
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>

namespace {
constexpr int kWidth=800,kHeight=480;
constexpr double kTextContrast=4.5,kIconContrast=3.0;
std::array<std::uint16_t,kWidth*kHeight> pixels{};
std::array<std::uint16_t,kWidth*40> draw_buffer{};
std::array<void*,4> supplementary_pools{};
std::ofstream checks;
unsigned failures=0;

void flush(lv_display_t* display,const lv_area_t* area,std::uint8_t* data){
    auto* source=reinterpret_cast<std::uint16_t*>(data);
    for(int y=area->y1;y<=area->y2;++y)for(int x=area->x1;x<=area->x2;++x)pixels[y*kWidth+x]=*source++;
    lv_display_flush_ready(display);
}
void pump(int rounds=12){for(int i=0;i<rounds;++i){preview_millis+=20;lv_tick_inc(20);calendar::tick_calendar_ui();ui_tick();lv_timer_handler();}}
void capture(const std::string& path){
    lv_obj_update_layout(lv_screen_active());lv_obj_invalidate(lv_screen_active());lv_refr_now(nullptr);
    std::ofstream output(path,std::ios::binary);output<<"P6\n800 480\n255\n";
    for(auto color:pixels){const auto r=(color>>11)&31,g=(color>>5)&63,b=color&31;const char rgb[]{static_cast<char>((r<<3)|(r>>2)),static_cast<char>((g<<2)|(g>>4)),static_cast<char>((b<<3)|(b>>2))};output.write(rgb,3);}
}
void check(bool condition,std::string_view name,std::string_view detail={}){checks<<(condition?"PASS ":"FAIL ")<<name;if(!detail.empty())checks<<": "<<detail;checks<<'\n';if(!condition)++failures;}
unsigned count_objects(lv_obj_t* object){unsigned n=1;for(unsigned i=0;i<lv_obj_get_child_count(object);++i)n+=count_objects(lv_obj_get_child(object,static_cast<int32_t>(i)));return n;}
unsigned total_objects(){unsigned n=0;for(auto* screen:{objects.main_screen,objects.agenda_screen,objects.month_screen,objects.weather_screen,objects.settings_screen,objects.event_details_screen,objects.brightness_settings_screen,objects.firmware_update_screen})n+=count_objects(screen);return n;}
void click(lv_obj_t* object){lv_obj_send_event(object,LV_EVENT_CLICKED,nullptr);pump();}
lv_obj_t* visible_child(lv_obj_t* parent,unsigned ordinal=0){if(!parent)return nullptr;for(unsigned i=0;i<lv_obj_get_child_count(parent);++i){auto* child=lv_obj_get_child(parent,static_cast<int32_t>(i));if(!lv_obj_has_flag(child,LV_OBJ_FLAG_HIDDEN)&&ordinal--==0)return child;}return nullptr;}
lv_obj_t* find_descendant_by_type(lv_obj_t* parent,const lv_obj_class_t* type){if(!parent)return nullptr;if(lv_obj_check_type(parent,type))return parent;for(unsigned i=0;i<lv_obj_get_child_count(parent);++i)if(auto* found=find_descendant_by_type(lv_obj_get_child(parent,static_cast<int32_t>(i)),type))return found;return nullptr;}
bool descendant_label_contains(lv_obj_t* parent,const char* needle){if(!parent)return false;if(lv_obj_check_type(parent,&lv_label_class)){const char* value=lv_label_get_text(parent);if(value&&std::strstr(value,needle))return true;}for(unsigned i=0;i<lv_obj_get_child_count(parent);++i)if(descendant_label_contains(lv_obj_get_child(parent,static_cast<int32_t>(i)),needle))return true;return false;}
lv_obj_t* visible_row_containing(lv_obj_t* parent,const char* needle){if(!parent)return nullptr;for(unsigned i=0;i<lv_obj_get_child_count(parent);++i){auto* child=lv_obj_get_child(parent,static_cast<int32_t>(i));if(!lv_obj_has_flag(child,LV_OBJ_FLAG_HIDDEN)&&descendant_label_contains(child,needle))return child;}return nullptr;}

std::uint32_t rgb888(lv_color_t color){return lv_color_to_u32(color)&0xFFFFFFU;}
double linear_channel(std::uint8_t value){const double c=static_cast<double>(value)/255.0;return c<=0.04045?c/12.92:std::pow((c+0.055)/1.055,2.4);}
double luminance(std::uint32_t c){return .2126*linear_channel(static_cast<std::uint8_t>(c>>16U))+.7152*linear_channel(static_cast<std::uint8_t>(c>>8U))+.0722*linear_channel(static_cast<std::uint8_t>(c));}
double contrast(std::uint32_t a,std::uint32_t b){const double x=luminance(a),y=luminance(b);return (std::max(x,y)+.05)/(std::min(x,y)+.05);}
std::string contrast_detail(std::uint32_t fg,std::uint32_t bg,double ratio){std::ostringstream out;out<<'#'<<std::hex<<std::setw(6)<<std::setfill('0')<<fg<<" on #"<<std::setw(6)<<bg<<std::dec<<std::fixed<<std::setprecision(2)<<" = "<<ratio<<":1";return out.str();}

void check_pressed_descendants(lv_obj_t* button,std::string_view name){
    if(!button)return;lv_obj_add_state(button,LV_STATE_PRESSED);pump(2);
    const auto bg=rgb888(lv_obj_get_style_bg_color_filtered(button,LV_PART_MAIN));
    std::vector<lv_obj_t*> pending;for(unsigned i=0;i<lv_obj_get_child_count(button);++i)pending.push_back(lv_obj_get_child(button,static_cast<int32_t>(i)));
    unsigned label_index=0;bool found=false;
    while(!pending.empty()){
        auto* child=pending.back();pending.pop_back();for(unsigned i=0;i<lv_obj_get_child_count(child);++i)pending.push_back(lv_obj_get_child(child,static_cast<int32_t>(i)));
        if(!lv_obj_check_type(child,&lv_label_class)||lv_obj_has_flag(child,LV_OBJ_FLAG_HIDDEN))continue;
        found=true;const auto fg=rgb888(lv_obj_get_style_text_color_filtered(child,LV_PART_MAIN));const double ratio=contrast(fg,bg);const char* text=lv_label_get_text(child);const bool icon=text&&(std::strcmp(text,"●")==0||std::strcmp(text,"○")==0);
        std::ostringstream label;label<<"pressed "<<name<<" child "<<label_index++<<" ["<<(text?text:"")<<']';
        check(ratio>=(icon?kIconContrast:kTextContrast),label.str(),contrast_detail(fg,bg,ratio));
    }
    check(found,std::string("pressed ")+std::string(name)+" has label child");lv_obj_remove_state(button,LV_STATE_PRESSED);pump(2);
}
void check_button_height(lv_obj_t* button,std::string_view name){if(!button||lv_obj_has_flag(button,LV_OBJ_FLAG_HIDDEN))return;lv_obj_update_layout(button);const auto h=lv_obj_get_height(button);check(h>=44,std::string(name)+" touch height",std::to_string(h)+" px");}
void check_wrapped_label(lv_obj_t* label,std::string_view name){
    if(!label||lv_obj_has_flag(label,LV_OBJ_FLAG_HIDDEN))return;lv_point_t size{};const char* text=lv_label_get_text(label);const auto* font=lv_obj_get_style_text_font(label,LV_PART_MAIN);
    lv_text_get_size(&size,text?text:"",font,lv_obj_get_style_text_letter_space(label,LV_PART_MAIN),lv_obj_get_style_text_line_space(label,LV_PART_MAIN),lv_obj_get_content_width(label),LV_TEXT_FLAG_NONE);
    std::ostringstream detail;detail<<"text "<<size.x<<'x'<<size.y<<" in "<<lv_obj_get_content_width(label)<<'x'<<lv_obj_get_content_height(label);check(size.y<=lv_obj_get_content_height(label),name,detail.str());
}
void check_single_line_label(lv_obj_t* label,std::string_view name){if(!label||lv_obj_has_flag(label,LV_OBJ_FLAG_HIDDEN))return;lv_point_t size{};const char* text=lv_label_get_text(label);const auto* font=lv_obj_get_style_text_font(label,LV_PART_MAIN);lv_text_get_size(&size,text?text:"",font,lv_obj_get_style_text_letter_space(label,LV_PART_MAIN),lv_obj_get_style_text_line_space(label,LV_PART_MAIN),LV_COORD_MAX,LV_TEXT_FLAG_NONE);std::ostringstream detail;detail<<"text "<<size.x<<" px in "<<lv_obj_get_content_width(label)<<" px";check(size.x<=lv_obj_get_content_width(label),name,detail.str());}

void capture_primary_screens(const std::string& directory){
    calendar::show_calendar_main();pump();capture(directory+"/today.ppm");calendar::show_calendar_primary_page();pump(20);capture(directory+"/week.ppm");calendar::show_calendar_month_view();pump(20);capture(directory+"/month.ppm");calendar::show_calendar_forecast();pump();capture(directory+"/forecast.ppm");calendar::show_calendar_settings();pump();capture(directory+"/settings.ppm");calendar::show_calendar_brightness_settings();pump();capture(directory+"/appearance.ppm");
}
void capture_pressed_states(const std::string& directory){
    calendar::show_calendar_main();pump();lv_obj_add_state(objects.main_wifi_button,LV_STATE_PRESSED);capture(directory+"/pressed-main-wifi.ppm");lv_obj_remove_state(objects.main_wifi_button,LV_STATE_PRESSED);pump(2);lv_obj_add_state(objects.main_settings_button,LV_STATE_PRESSED);capture(directory+"/pressed-main-settings.ppm");lv_obj_remove_state(objects.main_settings_button,LV_STATE_PRESSED);pump(2);
    auto* row=visible_child(objects.main_events_list);if(row){lv_obj_add_state(row,LV_STATE_PRESSED);capture(directory+"/pressed-main-row.ppm");lv_obj_remove_state(row,LV_STATE_PRESSED);pump(2);}lv_obj_add_state(objects.main_weather_card,LV_STATE_PRESSED);capture(directory+"/pressed-main-weather.ppm");lv_obj_remove_state(objects.main_weather_card,LV_STATE_PRESSED);pump(2);lv_obj_add_state(objects.main_nav_calendar_button,LV_STATE_PRESSED);capture(directory+"/pressed-main-navigation.ppm");lv_obj_remove_state(objects.main_nav_calendar_button,LV_STATE_PRESSED);pump(2);
}
void verify_pressed_contrast(){
    calendar::show_calendar_main();pump();
    for(const auto& item:std::array<std::pair<lv_obj_t*,const char*>,5>{{{objects.main_wifi_button,"main Wi-Fi"},{objects.main_settings_button,"main Settings"},{objects.main_nav_main_button,"main Today nav"},{objects.main_nav_calendar_button,"main Calendar nav"},{objects.main_nav_forecast_button,"main Forecast nav"}}})check_pressed_descendants(item.first,item.second);
    if(auto* row=visible_child(objects.main_events_list))check_pressed_descendants(row,"main event row");check_pressed_descendants(objects.main_weather_card,"main weather card");
    calendar::show_calendar_primary_page();pump();
    for(const auto& item:std::array<std::pair<lv_obj_t*,const char*>,10>{{{objects.agenda_wifi_button,"week Wi-Fi"},{objects.settings_button,"week Settings"},{objects.agenda_previous_button,"week Previous"},{objects.agenda_next_button,"week Next"},{objects.agenda_today_button,"week Today"},{objects.agenda_week_button,"week mode"},{objects.agenda_month_button,"month mode"},{objects.agenda_nav_main_button,"week Today nav"},{objects.agenda_nav_calendar_button,"week Calendar nav"},{objects.agenda_nav_forecast_button,"week Forecast nav"}}})check_pressed_descendants(item.first,item.second);
    if(auto* row=visible_child(objects.agenda_rows_container))check_pressed_descendants(row,"week event row");
    calendar::show_calendar_month_view();pump();check_pressed_descendants(objects.month_wifi_button,"month Wi-Fi");check_pressed_descendants(objects.month_settings_button,"month Settings");
    calendar::show_calendar_forecast();pump();for(const auto& item:std::array<std::pair<lv_obj_t*,const char*>,7>{{{objects.weather_back_button,"forecast Back"},{objects.weather_refresh_button,"forecast Refresh"},{objects.weather_set_location_button,"forecast location"},{objects.forecast_wifi_button,"forecast Wi-Fi"},{objects.forecast_nav_main_button,"forecast Today nav"},{objects.forecast_nav_calendar_button,"forecast Calendar nav"},{objects.forecast_nav_forecast_button,"forecast Forecast nav"}}})check_pressed_descendants(item.first,item.second);
    calendar::show_calendar_settings();pump();check_pressed_descendants(objects.settings_back_button,"settings Back");for(const auto& item:std::array<std::pair<lv_obj_t*,const char*>,6>{{{objects.settings_enter_wifi_button,"settings Wi-Fi"},{objects.settings_start_setup_button,"settings setup"},{objects.settings_sync_now_button,"settings sync"},{objects.settings_brightness_button,"settings appearance"},{objects.settings_weather_button,"settings weather"},{objects.settings_firmware_button,"settings firmware"}}})check_pressed_descendants(item.first,item.second);
    calendar::show_calendar_brightness_settings();pump();check_pressed_descendants(objects.brightness_back_button,"appearance Back");
}
void verify_geometry(){
    calendar::show_calendar_main();pump();lv_obj_update_layout(objects.main_screen);lv_area_t events{},weather{};lv_obj_get_coords(objects.main_events_container,&events);lv_obj_get_coords(objects.main_weather_card,&weather);check(events.y1==weather.y1,"main card top alignment");check(events.y2==weather.y2,"main card bottom alignment");check(descendant_label_contains(objects.main_events_list,"Work"),"Work source identity visible");check(descendant_label_contains(objects.main_events_list,"Family"),"Family source identity visible");check_wrapped_label(objects.main_weather_feels_value_label,"main feels value fit");check_wrapped_label(objects.main_weather_humidity_value_label,"main humidity value fit");check_wrapped_label(objects.main_weather_wind_value_label,"main wind value fit");
    for(const auto& item:std::array<std::pair<lv_obj_t*,const char*>,7>{{{objects.main_wifi_button,"main Wi-Fi"},{objects.main_settings_button,"main Settings"},{objects.main_weather_card,"main weather"},{objects.main_nav_main_button,"main Today nav"},{objects.main_nav_calendar_button,"main Calendar nav"},{objects.main_nav_forecast_button,"main Forecast nav"},{visible_child(objects.main_events_list),"main event row"}}})check_button_height(item.first,item.second);
    calendar::show_calendar_primary_page();pump();calendar::show_calendar_month_view();pump();auto* table=find_descendant_by_type(objects.month_grid_container,&lv_table_class);lv_mem_monitor_t month_memory{};lv_mem_monitor(&month_memory);std::ostringstream month_detail;month_detail<<"children="<<lv_obj_get_child_count(objects.month_grid_container)<<", state='"<<lv_label_get_text(objects.month_state_label)<<"', free="<<month_memory.free_size<<", biggest="<<month_memory.free_biggest_size;check(table,"month table exists",month_detail.str());if(table){check(lv_table_get_row_count(table)==6,"month has six rows");check(lv_obj_get_height(table)>=264,"month rows reserve 44 px",std::to_string(lv_obj_get_height(table))+" px table");}
    calendar::show_calendar_forecast();pump();check(!lv_obj_has_flag(objects.forecast_wifi_button,LV_OBJ_FLAG_HIDDEN),"forecast Wi-Fi control visible");for(auto* label:{objects.forecast_day_label_0,objects.forecast_day_label_1,objects.forecast_day_label_2,objects.forecast_day_label_3,objects.forecast_day_label_4,objects.forecast_day_label_5,objects.forecast_day_label_6})check_single_line_label(label,"forecast day label fit");for(auto* label:{objects.forecast_condition_label_0,objects.forecast_condition_label_1,objects.forecast_condition_label_2,objects.forecast_condition_label_3,objects.forecast_condition_label_4,objects.forecast_condition_label_5,objects.forecast_condition_label_6})check_wrapped_label(label,"forecast condition fit");
    calendar::show_calendar_brightness_settings();pump();lv_area_t back{},heading{};lv_obj_get_coords(objects.brightness_back_button,&back);lv_obj_get_coords(objects.appearance_heading_label,&heading);check(back.x2<heading.x1||heading.x2<back.x1,"appearance Back/title do not overlap",std::to_string(back.x2)+" vs "+std::to_string(heading.x1));
}
void verify_details_and_recovery(const std::string& directory){
    calendar::show_calendar_week_view();pump(30);auto* calendar_row=visible_row_containing(objects.agenda_rows_container,"deliberately long");check(calendar_row,"calendar long event row exists");if(calendar_row){click(calendar_row);check(lv_screen_active()==objects.event_details_screen,"calendar row opens Details");capture(directory+"/details-calendar-long.ppm");check_wrapped_label(objects.details_title_label,"details long title fit");check_wrapped_label(objects.details_location_label,"details long location fit");click(objects.details_back_button);check(lv_screen_active()==objects.agenda_screen,"Details Back returns to Week");}
    calendar::show_calendar_main();pump();auto* main_row=visible_child(objects.main_events_list);check(main_row,"main event row exists for deletion recovery");if(main_row){click(main_row);check(lv_screen_active()==objects.event_details_screen,"main row opens Details");calendar::refresh_without_selected_event_for_debug();pump();check(lv_screen_active()==objects.main_screen,"deleted Main event recovers to Main origin");const char* notice=lv_label_get_text(objects.main_events_hint_label);check(notice&&std::strstr(notice,"no longer available"),"deleted event notice is visible",notice?notice:"null");capture(directory+"/details-deleted-main-recovery.ppm");}
}
void capture_status_states(const std::string& directory){
    calendar::show_calendar_main();preview::connection={};pump(20);check(std::strcmp(lv_label_get_text(objects.main_wifi_label),"Starting...")==0,"starting connection state");capture(directory+"/status-starting.ppm");
    preview::connection.service_initialized=true;preview::connection.setup_ap_active=true;std::strcpy(preview::connection.setup_ssid,"Calendar Setup");std::strcpy(preview::connection.setup_password,"fixture-only");std::strcpy(preview::connection.setup_address,"192.168.4.1");pump(20);check(std::strcmp(lv_label_get_text(objects.main_wifi_label),"Setup Wi-Fi")==0,"setup AP connection state");capture(directory+"/status-setup.ppm");
    preview::set_fixture(false,false);pump(40);preview::connection.fetch_state=board::CalendarFetchState::Failed;std::strcpy(preview::connection.fetch_detail,"HTTPS read timeout");pump(20);check(std::strcmp(lv_label_get_text(objects.main_wifi_label),"Wi-Fi connected")==0,"connected state independent of sync failure");check(std::strstr(lv_label_get_text(objects.main_sync_state_label),"Sync failed - saved")!=nullptr,"sync failure overrides prior success",lv_label_get_text(objects.main_sync_state_label));capture(directory+"/status-connected-sync-failed.ppm");
}
void capture_negative_weather(const std::string& directory){
    const auto saved=preview::weather;preview::weather.current.temperature_tenths_c=-300;preview::weather.current.feels_like_tenths_c=-325;for(std::size_t i=0;i<preview::weather.forecast_count;++i){preview::weather.forecast[i].minimum_tenths_c=-350+static_cast<int>(i)*5;preview::weather.forecast[i].maximum_tenths_c=-300+static_cast<int>(i)*5;}++preview::weather_status.generation;
    calendar::show_calendar_main();pump(20);check_single_line_label(objects.main_weather_temperature_label,"negative Main temperature fit");capture(directory+"/weather-negative-main.ppm");calendar::show_calendar_forecast();pump(20);check_single_line_label(objects.weather_temperature_label,"negative Forecast temperature fit");for(auto* label:{objects.forecast_temp_label_0,objects.forecast_temp_label_1,objects.forecast_temp_label_2,objects.forecast_temp_label_3,objects.forecast_temp_label_4,objects.forecast_temp_label_5,objects.forecast_temp_label_6})check_single_line_label(label,"negative daily range fit");capture(directory+"/weather-negative-forecast.ppm");preview::weather=saved;++preview::weather_status.generation;pump(20);
}
void stress_navigation_and_themes(){
    calendar::show_calendar_settings();pump();calendar::show_calendar_brightness_settings();pump();for(unsigned warm=0;warm<calendar::kThemeCount;++warm){lv_dropdown_set_selected(objects.theme_style_dropdown,warm);calendar::change_calendar_theme_style();calendar::show_calendar_main();calendar::show_calendar_primary_page();calendar::show_calendar_month_view();calendar::show_calendar_settings();calendar::show_calendar_brightness_settings();pump(3);}pump(20);lv_mem_monitor_t before{};lv_mem_monitor(&before);const unsigned objects_before=total_objects();
    for(unsigned i=0;i<80;++i){lv_dropdown_set_selected(objects.theme_style_dropdown,i%calendar::kThemeCount);calendar::change_calendar_theme_style();if(i&1U)lv_obj_add_state(objects.dark_theme_switch,LV_STATE_CHECKED);else lv_obj_remove_state(objects.dark_theme_switch,LV_STATE_CHECKED);calendar::toggle_calendar_dark_theme();calendar::show_calendar_main();calendar::show_calendar_primary_page();calendar::show_calendar_month_view();calendar::show_calendar_forecast();calendar::show_calendar_settings();calendar::show_calendar_brightness_settings();pump(3);}pump(20);
    lv_mem_monitor_t after{};lv_mem_monitor(&after);const unsigned objects_after=total_objects();check(objects_after==objects_before,"navigation object count stable",std::to_string(objects_before)+" -> "+std::to_string(objects_after));const std::size_t used_before=before.total_size-before.free_size,used_after=after.total_size-after.free_size;check(used_after<=used_before+2048U,"navigation LVGL memory stabilizes",std::to_string(used_before)+" -> "+std::to_string(used_after)+" bytes");
}
}

int main(int argc,char** argv){
    if(argc<2){std::cerr<<"Usage: calendar_ui_preview OUTPUT_DIR [theme-id] [light|dark] [mixed|imperial]\n";return 2;}
    const std::string directory=argv[1];std::filesystem::create_directories(directory);checks.open(directory+"/checks.txt");setenv("TZ","IST-2IDT,M3.4.4/26,M10.5.0",1);tzset();std::tm local{};local.tm_year=126;local.tm_mon=8;local.tm_mday=28;local.tm_hour=9;local.tm_min=41;local.tm_isdst=-1;preview::now=std::mktime(&local);
    const int requested_theme=argc>2?std::atoi(argv[2]):static_cast<int>(calendar::kDefaultThemeId);const bool requested_dark=argc>3&&std::strcmp(argv[3],"dark")==0;preview::appearance.theme_id=calendar::theme_id_from_raw(static_cast<std::uint8_t>(requested_theme));preview::appearance.dark_theme=requested_dark;preview::set_fixture(argc>4&&std::strcmp(argv[4],"mixed")==0,argc>4&&std::strcmp(argv[4],"imperial")==0);
    lv_init();for(auto& pool:supplementary_pools){pool=std::malloc(64*1024);if(!pool||!lv_mem_add_pool(pool,64*1024)){std::cerr<<"Preview LVGL pool allocation failed\n";return 1;}}auto* display=lv_display_create(kWidth,kHeight);lv_display_set_color_format(display,LV_COLOR_FORMAT_RGB565);lv_display_set_buffers(display,draw_buffer.data(),nullptr,sizeof(draw_buffer),LV_DISPLAY_RENDER_MODE_PARTIAL);lv_display_set_flush_cb(display,flush);ui_init();calendar::initialize_calendar_ui();pump(40);
    capture_primary_screens(directory);capture_pressed_states(directory);verify_pressed_contrast();verify_geometry();verify_details_and_recovery(directory);capture_negative_weather(directory);capture_status_states(directory);stress_navigation_and_themes();
    lv_mem_monitor_t memory{};lv_mem_monitor(&memory);std::ofstream evidence(directory+"/runtime.txt");evidence<<"LVGL "<<LVGL_VERSION_MAJOR<<'.'<<LVGL_VERSION_MINOR<<'.'<<LVGL_VERSION_PATCH<<"; RGB565; real EEZ/controller; desktop service/clock/storage fixtures; no hardware\ntheme_id="<<requested_theme<<"\nmode="<<(requested_dark?"dark":"light")<<"\nobjects="<<total_objects()<<"\npool_bytes="<<memory.total_size<<"\nused_bytes="<<(memory.total_size-memory.free_size)<<"\npeak_used_bytes="<<memory.max_used<<"\nfailures="<<failures<<'\n';checks<<"SUMMARY failures="<<failures<<'\n';std::cout<<"LVGL "<<LVGL_VERSION_MAJOR<<'.'<<LVGL_VERSION_MINOR<<'.'<<LVGL_VERSION_PATCH<<" QA rendered; failures="<<failures<<'\n';return failures?1:0;
}
