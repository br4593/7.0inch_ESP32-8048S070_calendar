# Headless LVGL preview

This renderer compiles the actual generated screen tree, controller, actions,
fonts, themes and image assets against the resolved LVGL **9.2.2** checkout.
Desktop-only fixtures replace the board services, clock and preferences. It
does not exercise the RGB panel, touch driver, networking, flash or real PSRAM.
The preview uses the same five 64 KiB LVGL pools as the board runtime. Native
pointer sizes, display setup and allocator storage differ, so its memory numbers
are software allocation checks, not target heap measurements. It is excluded
from the PlatformIO `src` tree.

```sh
CCACHE_DISABLE=1 cmake -S tools/ui_preview -B /tmp/calendar-ui-preview -DCMAKE_BUILD_TYPE=Release
CCACHE_DISABLE=1 cmake --build /tmp/calendar-ui-preview --parallel 4
/tmp/calendar-ui-preview/calendar_ui_preview /tmp/calendar-ui-captures 4 light mixed
```

Theme IDs match `ThemeId`; modes are `light` and `dark`. Optional `mixed` tests
Hebrew/English content; `imperial` tests three-digit Fahrenheit temperatures.
Humidity is 100% to exercise the audited overflow boundary. The output is native
800 × 480 RGB PPM, directly reconstructed from LVGL's RGB565 flush buffer.

Each run captures the six primary screens, long Event Details, pressed controls,
deleted-event recovery, startup/setup/sync-failure states and negative weather.
The fixtures include distinct Work/Family identities and valid six-digit source
colors; `mixed` makes the Work identity bilingual. `checks.txt` records final
RGB565 composed pressed-state contrast for the actual LVGL button and child-label
styles, source identity, geometry/text fit, six Month rows, Back/origin behavior
and an 80-cycle navigation/theme memory check after warming every theme.
`runtime.txt` records the LVGL version, object count and allocator use. One or
more failed checks makes the renderer exit with status 1; a clean run exits 0.

Screenshots establish software layout only. Physical-panel observation is still
required for color, legibility, touch, redraw artifacts and stability. Desktop
allocator values use native pointer sizes and do not establish ESP32 heap or
PSRAM behavior. Service fixtures do not perform Wi-Fi, HTTPS, storage or OTA I/O.
