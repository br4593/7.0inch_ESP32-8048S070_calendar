#include "board/ota_boot_health.hpp"

#include <Arduino.h>

#include <esp_ota_ops.h>

#include <cstdio>

// Arduino-ESP32 2.0.x otherwise accepts a pending image in initArduino(),
// before setup() can assess display/UI health. This strong definition
// overrides the core's weak hook and leaves validation to OtaBootHealth.
#if defined(CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE) && CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE
extern "C" bool verifyRollbackLater() { return true; }
#endif

namespace board {
namespace {

constexpr std::uint32_t kHealthyWindowMs = 30U * 1000U;
constexpr std::uint32_t kMaximumHeartbeatGapMs = 2U * 1000U;

template <std::size_t Size>
void copy_text(char (&destination)[Size], const char* source) {
    std::snprintf(destination, Size, "%s", source == nullptr ? "" : source);
}

}  // namespace

void OtaBootHealth::initialize() {
    if (initialized_) return;
    initialized_ = true;

#if defined(CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE) && CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE
    status_.rollback_supported = true;
    const esp_partition_t* running = esp_ota_get_running_partition();
    esp_ota_img_states_t image_state = ESP_OTA_IMG_UNDEFINED;
    const esp_err_t result = running == nullptr
                                 ? ESP_ERR_NOT_FOUND
                                 : esp_ota_get_state_partition(running, &image_state);
    if (result == ESP_OK && image_state == ESP_OTA_IMG_PENDING_VERIFY) {
        status_.pending_verification = true;
        copy_text(status_.detail, "New firmware is in its 30-second health window");
    } else if (result == ESP_OK) {
        copy_text(status_.detail, "Running firmware does not require validation");
    } else {
        copy_text(status_.detail, "OTA image state is unavailable");
    }
#else
    status_.rollback_supported = false;
    copy_text(status_.detail, "Bootloader rollback support is disabled");
#endif
}

void OtaBootHealth::heartbeat() {
    if (!initialized_ || !status_.pending_verification || status_.marked_valid) return;
    const std::uint32_t now = millis();
    if (!status_.heartbeat_active ||
        static_cast<std::uint32_t>(now - last_heartbeat_ms_) > kMaximumHeartbeatGapMs) {
        healthy_since_ms_ = now;
        status_.healthy_seconds = 0;
    }
    last_heartbeat_ms_ = now;
    status_.heartbeat_active = true;
}

void OtaBootHealth::tick() {
    if (!initialized_ || !status_.pending_verification || status_.marked_valid ||
        !status_.heartbeat_active) {
        return;
    }
    const std::uint32_t now = millis();
    if (static_cast<std::uint32_t>(now - last_heartbeat_ms_) > kMaximumHeartbeatGapMs) {
        status_.heartbeat_active = false;
        status_.healthy_seconds = 0;
        copy_text(status_.detail, "Waiting for a continuous healthy-loop heartbeat");
        return;
    }

    const std::uint32_t healthy_ms = now - healthy_since_ms_;
    status_.healthy_seconds = healthy_ms / 1000U;
    if (healthy_ms < kHealthyWindowMs) return;

#if defined(CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE) && CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE
    if (esp_ota_mark_app_valid_cancel_rollback() == ESP_OK) {
        status_.marked_valid = true;
        status_.pending_verification = false;
        status_.healthy_seconds = kHealthyWindowMs / 1000U;
        copy_text(status_.detail, "Firmware marked valid after healthy startup");
    } else {
        status_.heartbeat_active = false;
        status_.healthy_seconds = 0;
        copy_text(status_.detail, "Could not mark firmware valid; rollback remains armed");
    }
#endif
}

OtaBootHealthStatus OtaBootHealth::status() const { return status_; }

OtaBootHealth& ota_boot_health() {
    static OtaBootHealth health;
    return health;
}

}  // namespace board
