#include "app/appearance_preferences.hpp"

#include <Preferences.h>

namespace calendar {
namespace {

constexpr char kPreferencesNamespace[] = "calendar-ui";
constexpr char kDarkThemeKey[] = "dark";
constexpr char kBrightnessKey[] = "brightness";

}  // namespace

std::uint8_t clamp_brightness_percent(std::uint8_t value) {
    if (value < kMinimumBrightnessPercent) return kMinimumBrightnessPercent;
    if (value > kMaximumBrightnessPercent) return kMaximumBrightnessPercent;
    return value;
}

AppearancePreferences load_appearance_preferences() {
    AppearancePreferences result;
    Preferences preferences;
    if (!preferences.begin(kPreferencesNamespace, true)) return result;
    result.dark_theme = preferences.getBool(kDarkThemeKey, result.dark_theme);
    result.brightness_percent = clamp_brightness_percent(
        preferences.getUChar(kBrightnessKey, kDefaultBrightnessPercent));
    preferences.end();
    return result;
}

bool save_appearance_preferences(const AppearancePreferences& appearance) {
    Preferences preferences;
    if (!preferences.begin(kPreferencesNamespace, false)) return false;
    const std::uint8_t brightness = clamp_brightness_percent(appearance.brightness_percent);
    preferences.putBool(kDarkThemeKey, appearance.dark_theme);
    preferences.putUChar(kBrightnessKey, brightness);
    const bool saved = preferences.isKey(kDarkThemeKey) && preferences.isKey(kBrightnessKey) &&
                       preferences.getBool(kDarkThemeKey, !appearance.dark_theme) == appearance.dark_theme &&
                       preferences.getUChar(kBrightnessKey, 0) == brightness;
    preferences.end();
    return saved;
}

}  // namespace calendar
