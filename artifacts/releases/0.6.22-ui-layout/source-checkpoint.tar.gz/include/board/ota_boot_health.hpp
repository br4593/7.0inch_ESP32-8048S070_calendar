#pragma once

#include <cstdint>

namespace board {

struct OtaBootHealthStatus {
    bool rollback_supported = false;
    bool pending_verification = false;
    bool heartbeat_active = false;
    bool marked_valid = false;
    std::uint32_t healthy_seconds = 0;
    char detail[96]{};
};

// Delays accepting a newly booted OTA image until the application has supplied
// a continuous healthy-loop heartbeat for 30 seconds. Network availability is
// deliberately not part of this health decision.
class OtaBootHealth {
public:
    void initialize();
    void heartbeat();
    void tick();
    OtaBootHealthStatus status() const;

private:
    bool initialized_ = false;
    std::uint32_t healthy_since_ms_ = 0;
    std::uint32_t last_heartbeat_ms_ = 0;
    OtaBootHealthStatus status_{};
};

OtaBootHealth& ota_boot_health();

}  // namespace board
