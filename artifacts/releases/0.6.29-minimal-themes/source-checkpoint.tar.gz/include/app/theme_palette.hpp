#pragma once

#include <cstdint>

namespace calendar {

// Values are persisted in NVS. Append new themes before Count and never
// renumber an existing entry.
enum class ThemeId : std::uint8_t {
    ModernQuiet = 0,
    SwissGrid = 1,
    BauhausPrimary = 2,
    NordicQuiet = 3,
    Count = 4,
};

inline constexpr ThemeId kDefaultThemeId = ThemeId::ModernQuiet;
constexpr std::uint8_t kThemeCount = static_cast<std::uint8_t>(ThemeId::Count);

constexpr bool is_valid_theme_id(ThemeId theme) {
    return static_cast<std::uint8_t>(theme) < kThemeCount;
}

// Semantic colors shared by every theme family. Consumers select colors by
// role so each light/dark appearance remains complete and consistent.
struct ThemePalette {
    std::uint32_t canvas;
    std::uint32_t surface;
    std::uint32_t surface_subtle;
    std::uint32_t surface_muted;
    std::uint32_t input_inset;
    std::uint32_t header;
    std::uint32_t on_header;
    std::uint32_t text_primary;
    std::uint32_t text_secondary;
    std::uint32_t text_muted;
    std::uint32_t border;
    std::uint32_t divider;
    std::uint32_t action;
    std::uint32_t on_action;
    std::uint32_t action_pressed;
    std::uint32_t selection;
    std::uint32_t on_selection;
    std::uint32_t action_soft;
    std::uint32_t focus;
    std::uint32_t today_fill;
    std::uint32_t today_text;
    std::uint32_t today_ring;
    std::uint32_t status_normal;
    std::uint32_t status_attention;
    std::uint32_t status_error;
};

// Only the small geometry details that are allowed to vary between themes.
// Layout, hit targets and navigation geometry remain shared by every theme.
struct ThemeMetrics {
    std::uint8_t card_radius;
    std::uint8_t control_radius;
    std::uint8_t input_radius;
    std::uint8_t divider_width;
};

ThemeId theme_id_from_raw(std::uint8_t raw_theme_id);
const char* theme_name(ThemeId theme);
const ThemeMetrics& theme_metrics(ThemeId theme);
const ThemePalette& palette_for(ThemeId theme, bool dark_theme);

// Compatibility accessors retain the existing Modern Quiet behavior.
const ThemePalette& light_palette();
const ThemePalette& dark_palette();
const ThemePalette& palette_for(bool dark_theme);

}  // namespace calendar
