#include "app/theme_palette.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>

namespace {

int failures = 0;
#define CHECK(...) do { if (!(__VA_ARGS__)) { ++failures; std::cerr << __FUNCTION__ << ": " #__VA_ARGS__ " failed at " << __LINE__ << '\n'; } } while (false)

double linear_channel(std::uint8_t value) {
    const double channel = static_cast<double>(value) / 255.0;
    return channel <= 0.04045 ? channel / 12.92
                              : std::pow((channel + 0.055) / 1.055, 2.4);
}

double luminance(std::uint32_t color) {
    return 0.2126 * linear_channel(static_cast<std::uint8_t>(color >> 16U)) +
           0.7152 * linear_channel(static_cast<std::uint8_t>(color >> 8U)) +
           0.0722 * linear_channel(static_cast<std::uint8_t>(color));
}

double contrast_ratio(std::uint32_t first, std::uint32_t second) {
    const double first_luminance = luminance(first);
    const double second_luminance = luminance(second);
    const double lighter = std::max(first_luminance, second_luminance);
    const double darker = std::min(first_luminance, second_luminance);
    return (lighter + 0.05) / (darker + 0.05);
}

std::uint32_t rgb565_round_trip(std::uint32_t color) {
    const std::uint8_t red5 = static_cast<std::uint8_t>((color >> 19U) & 0x1FU);
    const std::uint8_t green6 = static_cast<std::uint8_t>((color >> 10U) & 0x3FU);
    const std::uint8_t blue5 = static_cast<std::uint8_t>((color >> 3U) & 0x1FU);
    const std::uint8_t red8 = static_cast<std::uint8_t>((red5 << 3U) | (red5 >> 2U));
    const std::uint8_t green8 = static_cast<std::uint8_t>((green6 << 2U) | (green6 >> 4U));
    const std::uint8_t blue8 = static_cast<std::uint8_t>((blue5 << 3U) | (blue5 >> 2U));
    return (static_cast<std::uint32_t>(red8) << 16U) |
           (static_cast<std::uint32_t>(green8) << 8U) |
           static_cast<std::uint32_t>(blue8);
}

void check_contrast_contract(const calendar::ThemePalette& palette, bool quantize_to_rgb565) {
    constexpr double kMinimumContrast = 4.5;
    constexpr double kMinimumNonTextContrast = 3.0;
    const auto color = [quantize_to_rgb565](std::uint32_t value) {
        return quantize_to_rgb565 ? rgb565_round_trip(value) : value;
    };
    const auto contrast = [&color](std::uint32_t first, std::uint32_t second) {
        return contrast_ratio(color(first), color(second));
    };
    CHECK(contrast(palette.text_primary, palette.surface) >= kMinimumContrast);
    CHECK(contrast(palette.text_secondary, palette.surface) >= kMinimumContrast);
    CHECK(contrast(palette.text_muted, palette.surface) >= kMinimumContrast);
    CHECK(contrast(palette.text_secondary, palette.input_inset) >= kMinimumContrast);
    CHECK(contrast(palette.action, palette.on_action) >= kMinimumContrast);
    CHECK(contrast(palette.action_pressed, palette.on_action) >= kMinimumContrast);
    CHECK(contrast(palette.selection, palette.on_selection) >= kMinimumContrast);
    CHECK(contrast(palette.today_fill, palette.today_text) >= kMinimumContrast);
    CHECK(contrast(palette.header, palette.on_header) >= kMinimumContrast);
    CHECK(contrast(palette.header, palette.status_normal) >= kMinimumContrast);
    CHECK(contrast(palette.header, palette.status_attention) >= kMinimumContrast);
    CHECK(contrast(palette.header, palette.status_error) >= kMinimumContrast);
    CHECK(contrast(palette.focus, palette.input_inset) >= kMinimumNonTextContrast);
    CHECK(contrast(palette.today_ring, palette.today_fill) >= kMinimumNonTextContrast);
}

void test_selection_and_exact_tokens() {
    const calendar::ThemePalette& light = calendar::light_palette();
    const calendar::ThemePalette& dark = calendar::dark_palette();
    CHECK(&calendar::palette_for(false) == &light);
    CHECK(&calendar::palette_for(true) == &dark);
    CHECK(light.canvas == 0xF4F6F7U && light.surface == 0xFFFFFFU &&
          light.surface_subtle == 0xF7F9FAU && light.surface_muted == 0xE9EFF1U &&
          light.input_inset == 0xEEF2F3U && light.header == 0x142A33U &&
          light.on_header == 0xFFFFFFU && light.text_primary == 0x122B34U &&
          light.text_secondary == 0x38535DU && light.text_muted == 0x5B737BU &&
          light.border == 0x7A9098U && light.divider == 0xC4D0D4U &&
          light.action == 0x147A8AU && light.on_action == 0xFFFFFFU &&
          light.action_pressed == 0x0E5A66U && light.selection == 0x147A8AU &&
          light.on_selection == 0xFFFFFFU && light.action_soft == 0xDCECEFU &&
          light.focus == 0x0A7184U && light.today_fill == 0xFFF0D5U &&
          light.today_text == 0x704400U && light.today_ring == 0xA56600U &&
          light.status_normal == 0xBFE7ECU && light.status_attention == 0xFFD486U &&
          light.status_error == 0xFFB7AEU);
    CHECK(dark.canvas == 0x0E161BU && dark.surface == 0x141E24U &&
          dark.surface_subtle == 0x19262DU && dark.surface_muted == 0x111B21U &&
          dark.input_inset == 0x0F181DU && dark.header == 0x080F13U &&
          dark.on_header == 0xFFFFFFU && dark.text_primary == 0xF1F6F8U &&
          dark.text_secondary == 0xD3E0E4U && dark.text_muted == 0xA4B7BEU &&
          dark.border == 0x5A717AU && dark.divider == 0x2A3B43U &&
          dark.action == 0x5BC2D5U && dark.on_action == 0x071419U &&
          dark.action_pressed == 0x3196AAU && dark.selection == 0x285C69U &&
          dark.on_selection == 0xFFFFFFU && dark.action_soft == 0x213B43U &&
          dark.focus == 0x73D3E3U && dark.today_fill == 0x493A20U &&
          dark.today_text == 0xFFD58CU && dark.today_ring == 0xDEA34EU &&
          dark.status_normal == 0xBDEAF0U && dark.status_attention == 0xFFD58CU &&
          dark.status_error == 0xFFB7AEU);
}

void test_stable_ids_names_and_metrics() {
    using calendar::ThemeId;
    CHECK(static_cast<std::uint8_t>(ThemeId::ModernQuiet) == 0U);
    CHECK(static_cast<std::uint8_t>(ThemeId::SwissGrid) == 1U);
    CHECK(static_cast<std::uint8_t>(ThemeId::BauhausPrimary) == 2U);
    CHECK(static_cast<std::uint8_t>(ThemeId::NordicQuiet) == 3U);
    CHECK(calendar::kThemeCount == 4U);

    constexpr std::array<ThemeId, calendar::kThemeCount> themes{
        ThemeId::ModernQuiet, ThemeId::SwissGrid,
        ThemeId::BauhausPrimary, ThemeId::NordicQuiet};
    constexpr std::array<const char*, calendar::kThemeCount> names{
        "Modern Quiet", "Swiss Grid", "Bauhaus Primary", "Nordic Quiet"};
    constexpr std::array<std::uint8_t, calendar::kThemeCount> radii{8, 2, 0, 8};
    for (std::size_t index = 0; index < themes.size(); ++index) {
        CHECK(calendar::is_valid_theme_id(themes[index]));
        CHECK(calendar::theme_id_from_raw(static_cast<std::uint8_t>(themes[index])) == themes[index]);
        CHECK(std::strcmp(calendar::theme_name(themes[index]), names[index]) == 0);
        const calendar::ThemeMetrics& metrics = calendar::theme_metrics(themes[index]);
        CHECK(metrics.card_radius == radii[index]);
        CHECK(metrics.control_radius == radii[index]);
        CHECK(metrics.input_radius == radii[index]);
        CHECK(metrics.card_radius <= 8U);
        CHECK(metrics.control_radius <= 8U);
        CHECK(metrics.input_radius <= 8U);
        CHECK(metrics.divider_width == 1U);
        CHECK(&calendar::palette_for(themes[index], false) !=
              &calendar::palette_for(themes[index], true));
    }

    CHECK(!calendar::is_valid_theme_id(static_cast<ThemeId>(calendar::kThemeCount)));
    CHECK(!calendar::is_valid_theme_id(static_cast<ThemeId>(255U)));
    CHECK(calendar::theme_id_from_raw(calendar::kThemeCount) == ThemeId::ModernQuiet);
    CHECK(calendar::theme_id_from_raw(255U) == ThemeId::ModernQuiet);
    const ThemeId invalid = static_cast<ThemeId>(255U);
    CHECK(std::strcmp(calendar::theme_name(invalid), "Modern Quiet") == 0);
    CHECK(&calendar::theme_metrics(invalid) == &calendar::theme_metrics(ThemeId::ModernQuiet));
    CHECK(&calendar::palette_for(invalid, false) ==
          &calendar::palette_for(ThemeId::ModernQuiet, false));
}

void test_theme_identity_tokens() {
    using calendar::ThemeId;
    const calendar::ThemePalette& swiss_light = calendar::palette_for(ThemeId::SwissGrid, false);
    const calendar::ThemePalette& swiss_dark = calendar::palette_for(ThemeId::SwissGrid, true);
    CHECK(swiss_light.header == 0x111111U && swiss_light.action == 0xB72025U &&
          swiss_light.selection == 0x111111U && swiss_light.today_fill == 0xFFE6A3U);
    CHECK(swiss_dark.header == 0x000000U && swiss_dark.action == 0xFF5B5FU &&
          swiss_dark.selection == 0x333333U && swiss_dark.today_text == 0xFFD97AU);

    const calendar::ThemePalette& bauhaus_light =
        calendar::palette_for(ThemeId::BauhausPrimary, false);
    const calendar::ThemePalette& bauhaus_dark =
        calendar::palette_for(ThemeId::BauhausPrimary, true);
    CHECK(bauhaus_light.header == 0x151515U && bauhaus_light.action == 0x0047ABU &&
          bauhaus_light.selection == 0xC62828U && bauhaus_light.today_fill == 0xF5C400U);
    CHECK(bauhaus_dark.action == 0x66A3FFU && bauhaus_dark.selection == 0xA93633U &&
          bauhaus_dark.today_text == 0xFFE072U);

    const calendar::ThemePalette& nordic_light =
        calendar::palette_for(ThemeId::NordicQuiet, false);
    const calendar::ThemePalette& nordic_dark =
        calendar::palette_for(ThemeId::NordicQuiet, true);
    CHECK(nordic_light.header == 0x23332DU && nordic_light.action == 0x286B57U &&
          nordic_light.today_fill == 0xF6E8C8U);
    CHECK(nordic_dark.header == 0x09100DU && nordic_dark.action == 0x69C6A8U &&
          nordic_dark.selection == 0x285B4AU);
}

void test_accessible_contrast() {
    using calendar::ThemeId;
    constexpr std::array<ThemeId, calendar::kThemeCount> themes{
        ThemeId::ModernQuiet, ThemeId::SwissGrid,
        ThemeId::BauhausPrimary, ThemeId::NordicQuiet};
    for (ThemeId theme : themes) {
        for (bool dark : {false, true}) {
            const calendar::ThemePalette& palette = calendar::palette_for(theme, dark);
            check_contrast_contract(palette, false);
            check_contrast_contract(palette, true);
        }
    }
}

}  // namespace

int main() {
    test_selection_and_exact_tokens();
    test_stable_ids_names_and_metrics();
    test_theme_identity_tokens();
    test_accessible_contrast();
    if (failures != 0) {
        std::cerr << failures << " theme palette test(s) failed\n";
        return 1;
    }
    std::cout << "theme palette tests passed\n";
    return 0;
}
