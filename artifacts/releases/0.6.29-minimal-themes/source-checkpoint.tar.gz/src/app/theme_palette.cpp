#include "app/theme_palette.hpp"

namespace calendar {
namespace {

struct ThemeRecord {
    const char* name;
    ThemeMetrics metrics;
    ThemePalette light;
    ThemePalette dark;
};

constexpr ThemePalette kModernQuietLight{
    0xF4F6F7, 0xFFFFFF, 0xF7F9FA, 0xE9EFF1, 0xEEF2F3, 0x142A33,
    0xFFFFFF, 0x122B34, 0x38535D, 0x5B737B, 0x7A9098, 0xC4D0D4, 0x147A8A,
    0xFFFFFF, 0x0E5A66, 0x147A8A, 0xFFFFFF, 0xDCECEF, 0x0A7184,
    0xFFF0D5, 0x704400, 0xA56600, 0xBFE7EC, 0xFFD486, 0xFFB7AE,
};

constexpr ThemePalette kModernQuietDark{
    0x0E161B, 0x141E24, 0x19262D, 0x111B21, 0x0F181D, 0x080F13,
    0xFFFFFF, 0xF1F6F8, 0xD3E0E4, 0xA4B7BE, 0x5A717A, 0x2A3B43, 0x5BC2D5,
    0x071419, 0x3196AA, 0x285C69, 0xFFFFFF, 0x213B43, 0x73D3E3,
    0x493A20, 0xFFD58C, 0xDEA34E, 0xBDEAF0, 0xFFD58C, 0xFFB7AE,
};

constexpr ThemePalette kSwissGridLight{
    0xF5F5F2, 0xFFFFFF, 0xF0F0EC, 0xE5E5E0, 0xF3F3EF, 0x111111,
    0xFFFFFF, 0x111111, 0x383838, 0x5C5C5C, 0x777770, 0xC8C8C0, 0xB72025,
    0xFFFFFF, 0x87171B, 0x111111, 0xFFFFFF, 0xF6DDDE, 0xB72025,
    0xFFE6A3, 0x4C3500, 0x9A6200, 0xCDEAE0, 0xFFE19C, 0xF4B8B6,
};

constexpr ThemePalette kSwissGridDark{
    0x101010, 0x181818, 0x202020, 0x151515, 0x131313, 0x000000,
    0xFFFFFF, 0xF5F5F2, 0xD6D6D0, 0xA8A8A0, 0x707068, 0x333330, 0xFF5B5F,
    0x1A0001, 0xE54C52, 0x333333, 0xFFFFFF, 0x3A2324, 0xFF7478,
    0x3E3210, 0xFFD97A, 0xE3A900, 0xCDEAE0, 0xFFE19C, 0xF4B8B6,
};

constexpr ThemePalette kBauhausPrimaryLight{
    0xF4EEDC, 0xFFFAF0, 0xF6F0E3, 0xE5DEC9, 0xF0E8D5, 0x151515,
    0xFFFFFF, 0x171717, 0x403D37, 0x625E55, 0x7E786D, 0xCCC4B3, 0x0047AB,
    0xFFFFFF, 0x00347E, 0xC62828, 0xFFFFFF, 0xDDE7F5, 0x0047AB,
    0xF5C400, 0x2A2100, 0x7A5F00, 0xC7E2F2, 0xF5C400, 0xF5B8B0,
};

constexpr ThemePalette kBauhausPrimaryDark{
    0x12110E, 0x1D1B16, 0x25221B, 0x171510, 0x16140F, 0x050505,
    0xFFFFFF, 0xF7F3E8, 0xD9D3C5, 0xAAA497, 0x746E62, 0x38342B, 0x66A3FF,
    0x07142A, 0x548FDC, 0xA93633, 0xFFFFFF, 0x253248, 0x85B8FF,
    0x4A3C00, 0xFFE072, 0xD8AD00, 0xC7E2F2, 0xF5C400, 0xF5B8B0,
};

constexpr ThemePalette kNordicQuietLight{
    0xF2F4F1, 0xFEFFFC, 0xF6F8F4, 0xE5EAE4, 0xEDF1EC, 0x23332D,
    0xFFFFFF, 0x17231F, 0x3D514A, 0x596D65, 0x778A82, 0xCAD4CE, 0x286B57,
    0xFFFFFF, 0x1C4F40, 0x286B57, 0xFFFFFF, 0xDCEBE5, 0x1D6551,
    0xF6E8C8, 0x5A3D00, 0x9B6E1B, 0xD0E8DE, 0xF4D99A, 0xF1B9AE,
};

constexpr ThemePalette kNordicQuietDark{
    0x101713, 0x16211C, 0x1D2A24, 0x111B16, 0x111A16, 0x09100D,
    0xFFFFFF, 0xF3F7F4, 0xD5E1DB, 0x9FB3AA, 0x60776D, 0x2A3B33, 0x69C6A8,
    0x08140F, 0x47A589, 0x285B4A, 0xFFFFFF, 0x213A31, 0x7AD7B8,
    0x47391F, 0xFFD58C, 0xD8A34F, 0xD0E8DE, 0xF4D99A, 0xF1B9AE,
};

constexpr ThemeRecord kThemes[]{
    {"Modern Quiet", {8, 8, 8, 1}, kModernQuietLight, kModernQuietDark},
    {"Swiss Grid", {2, 2, 2, 1}, kSwissGridLight, kSwissGridDark},
    {"Bauhaus Primary", {0, 0, 0, 1}, kBauhausPrimaryLight, kBauhausPrimaryDark},
    {"Nordic Quiet", {8, 8, 8, 1}, kNordicQuietLight, kNordicQuietDark},
};

static_assert(sizeof(kThemes) / sizeof(kThemes[0]) == kThemeCount,
              "ThemeId and theme table must stay in sync");

std::uint8_t theme_index(ThemeId theme) {
    return is_valid_theme_id(theme) ? static_cast<std::uint8_t>(theme)
                                    : static_cast<std::uint8_t>(kDefaultThemeId);
}

}  // namespace

ThemeId theme_id_from_raw(std::uint8_t raw_theme_id) {
    const ThemeId theme = static_cast<ThemeId>(raw_theme_id);
    return is_valid_theme_id(theme) ? theme : kDefaultThemeId;
}

const char* theme_name(ThemeId theme) { return kThemes[theme_index(theme)].name; }

const ThemeMetrics& theme_metrics(ThemeId theme) {
    return kThemes[theme_index(theme)].metrics;
}

const ThemePalette& palette_for(ThemeId theme, bool dark_theme) {
    const ThemeRecord& record = kThemes[theme_index(theme)];
    return dark_theme ? record.dark : record.light;
}

const ThemePalette& light_palette() {
    return palette_for(ThemeId::ModernQuiet, false);
}

const ThemePalette& dark_palette() {
    return palette_for(ThemeId::ModernQuiet, true);
}

const ThemePalette& palette_for(bool dark_theme) {
    return palette_for(ThemeId::ModernQuiet, dark_theme);
}

}  // namespace calendar
