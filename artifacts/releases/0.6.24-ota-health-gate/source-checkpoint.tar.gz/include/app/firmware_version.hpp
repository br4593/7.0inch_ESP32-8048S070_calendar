#pragma once

namespace calendar {

#if defined(APP_RGB_STAGED_STARTUP)
inline constexpr char kFirmwareVersion[] = "0.6.24-ota-health-gate";
#elif defined(APP_RGB_DIAGNOSTICS)
inline constexpr char kFirmwareVersion[] = "0.6.19-rgb-diagnostics";
#elif defined(APP_OWN_ST7262_PANEL)
inline constexpr char kFirmwareVersion[] = "0.6.17-weather-image-icons";
#else
inline constexpr char kFirmwareVersion[] = "0.6.11-rgb-single-flush-owner";
#endif

}  // namespace calendar
